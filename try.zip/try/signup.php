<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = $_POST['first_name'];
    $lastname = $_POST['last_name'];
    $username = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];
    $found = false;
    //                                      $image = addslashes(file_get_contents($_FILES['pic']['tmp_name']));
    // $sex = $_POST['gender'];
    $user_id;

    $conn = new mysqli("localhost", "root", "", "opportunity");

    if ($conn) {
        do {
            $user_id = rand(100000000, 999999999);
            $sql = "SELECT * FROM user WHERE user_ID='$user_id'";
            $result = mysqli_query($conn, $sql);
        } while (mysqli_num_rows($result) > 0);


        $sql = "SELECT * FROM user WHERE user_username='$username' AND user_password = '$password'";
        $result = mysqli_query($conn, $sql);
        $num = mysqli_num_rows($result);
        if($num > 0)
        {
            $_SESSION['error'] = "Incorrect email or password."; 
            header('Location: opportUnity_signup.php'); 
            exit(); 
        }
        else{
            //$sql = "INSERT INTO user(user_ID, user_fullname, user_username, user_password, profile_photo) VALUES ('$user_id', '$fullname', '$username', '$password', '$image')";
            //$sql = "INSERT INTO user(user_ID, user_fullname, user_username, user_password, user_sex) VALUES ('$user_id', '$fullname', '$username', '$password', '$sex')";
            $sql = "INSERT INTO user(user_ID, user_type, user_firstname, user_lastname, user_username, user_password) VALUES ('$user_id', '$role', '$firstname', '$lastname', '$username', '$password')";
            $result = mysqli_query($conn, $sql);

            if ($result) {
                echo "<script>alert('Account created');</script>";
                echo "<script>window.location.replace('opportUnity_login.php');</script>";
                $found = true;
            } else {
                echo "Error: " . mysqli_error($conn);
            }
        }
        

    } else {
        echo "Connection failed: " . mysqli_connect_error();
    }
}
?>